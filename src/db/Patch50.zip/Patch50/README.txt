CAEFISS2.0 v5.0 Database Scripts
Please run the following SQL files in order

1.  CAF-138.sql
2.  CAF-139.sql
3.  CAF-159.sql
4.  CAF-169.sql
5.  CAF-171.sql
6.  CAF-172.sql
7.  CAF-173.sql
8.  CAF-197.sql
9.  CAF-233.sql
10. CAF-234.sql
11. create_private_synonyms.sql

12. CAF-106.sql
13. CAF-172-patch.sql