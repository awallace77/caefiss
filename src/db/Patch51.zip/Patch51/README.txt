CAEFISS2.0 v5.1 Database Scripts

Please run the following SQL files in order

1. CAF-204.sql
2. CAF-205.sql
3. CAF-206.sql
4. CAF-207.sql
5. CAF-209.sql
6. CAF-211.sql
7. CAF-212.sql
8. CAF-213.sql
9. CAF-214.sql
10. CAF-316.sql
11. CAF-318.sql
12. create_private_synonyms.sql
13. CAF-491.sql

14. CAF-556.sql
15. CAF-555.sql
 